# Birthday Opi ♡

Upload `index.html` to the root of your GitHub repository. Enable GitHub Pages from Settings → Pages → Deploy from a branch → `main` → `/ (root)`.

Opening sequence: tap the gift, then enter password `16-11-06`. The favorite-song title and artist text can be edited in the page. Replace the gradient album-art block with a real cover image if desired.
